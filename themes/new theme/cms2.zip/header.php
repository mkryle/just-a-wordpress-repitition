<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>cms2</title>
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <link rel="stylesheet" href="style.css">

  <?php wp_head();?>
</head>
<body>

<div id="nav">
<?php wp_nav_menu( ['theme_location' => 'nav']) ?>
<br><br>
</div>
