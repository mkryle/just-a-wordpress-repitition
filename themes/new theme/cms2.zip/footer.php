
<p> end of site (footer)</p>
<?php

wp_footer(); ?>
</body>
</html>
